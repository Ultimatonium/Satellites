﻿public abstract class StaticSpaceObject : SpaceObject
{
}
