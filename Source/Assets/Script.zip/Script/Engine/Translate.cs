﻿using UnityEngine;

public class Translate
{
    private static double[,] translation = new double[4, 4] { {1,0,0,0}
                                                            , {0,1,0,0}
                                                            , {0,0,1,0}
                                                            , {0,0,0,1}
                                                            };
    public static Mesh TranslateMesh(Mesh mesh, VectorXYZ delta)
    {
        mesh.vertices = TranslateVector3(mesh.vertices, delta);
        return mesh;
    }

    private static Vector3[] TranslateVector3(Vector3[] vertices, VectorXYZ delta)
    {
        return VectorXYZ.ToVector3(TranslateVectorXYZ(VectorXYZ.FromVector3(vertices), delta));
    }

    private static VectorXYZ[] TranslateVectorXYZ(VectorXYZ[] vertices, VectorXYZ delta)
    {
        translation[0, 3] = delta.x;
        translation[1, 3] = delta.y;
        translation[2, 3] = delta.z;
        for (int i = 0; i < vertices.Length; i++)
        {
            vertices[i] = translation * vertices[i];
        }
        return vertices;
    }
}