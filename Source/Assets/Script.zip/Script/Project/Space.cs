﻿using UnityEngine;

public class Space : MonoBehaviour
{
    internal const double rotationScale = 10000;
    public const int scale = -10;
    public const bool debug = false;

    private void Awake()
    {
        Time.timeScale = 1f;
    }
}
